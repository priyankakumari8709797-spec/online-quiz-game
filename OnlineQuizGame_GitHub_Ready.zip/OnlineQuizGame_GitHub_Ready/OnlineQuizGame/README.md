# Online Quiz Game (C++)

A modular, console-based quiz application built in C++ featuring secure user
authentication, a persistent file-based question bank, randomized
non-repeating questions per session, real-time scoring, and a results
summary — built to demonstrate OOP design and file handling in C++.

## Features
- **User authentication** — signup and login, credentials persisted in `users.txt`.
- **Persistent question bank** — questions stored in `questions.txt` (pipe-delimited), so you can add/edit questions without recompiling.
- **Randomized quiz** — questions are shuffled each session so no two runs feel identical.
- **Real-time scoring** — immediate feedback after every answer.
- **High score tracking** — each user's best score is saved and shown on request.
- **Input validation** — invalid menu choices or answers are rejected gracefully instead of crashing.

## Tech Stack
- **Language:** C++ (C++17)
- **Concepts used:** Object-Oriented Programming (classes `Question`, `User`), file I/O (`fstream`), STL containers (`vector`), randomization (`<random>`), input validation.

## Project Structure
```
OnlineQuizGame/
├── main.cpp          # All game logic
├── questions.txt      # Editable question bank (pipe-delimited)
├── users.txt          # Auto-created/updated at runtime — stores user data
├── .gitignore
└── README.md
```

## How to Run

### Option 1: VS Code (with C++ extension)
1. Open this folder in VS Code.
2. Install the "C/C++" extension (Microsoft) if you don't have it.
3. Open `main.cpp`, then Run ▶ (or use the terminal method below).

### Option 2: Terminal (works on Windows/Mac/Linux with g++ installed)
```bash
g++ -std=c++17 -Wall -o quizgame main.cpp
./quizgame        # on Windows: quizgame.exe
```

## Editing the Question Bank
Open `questions.txt`. Each line follows this format:
```
category|question text|option1|option2|option3|option4|correctIndex(0-3)
```
Example:
```
Web|What does CSS stand for?|Cascading Style Sheets|Computer Style Sheets|Creative Style Sheets|Colorful Style Sheets|0
```
Add as many lines as you like — no recompiling needed.

## Note on Passwords
For simplicity, this console project stores passwords in plain text in
`users.txt`. This is fine for a learning/portfolio project, but in a
production system you'd hash passwords (e.g. with bcrypt) before storing them.

## Author
**Priyanka Kumari** — BCA Student, Uttaranchal University


## Screenshots

### Login
![Login](screenshots/screenshot_1_login.png)

### Main Menu & Subject Selection
![Main Menu](screenshots/screenshot_2_main_menu.png)

### Quiz & Results
![Quiz Result](screenshots/screenshot_3_quiz_result.png)
